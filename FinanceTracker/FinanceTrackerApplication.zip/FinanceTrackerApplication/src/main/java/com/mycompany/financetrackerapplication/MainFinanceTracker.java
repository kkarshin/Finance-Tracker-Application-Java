/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.financetrackerapplication;

import gui.Login;
// import test.TestFinanceTracker;
// import test.TestGUIIntegration;

/**
 *
 * @author Hp
 */
public class MainFinanceTracker {
    // testing usage
    public static void main(String[] args) {
//        // Create login object and display login window when run
//        // Call method setVisible(boolean)to display the components of the object on the screen
       Login login = new Login();
       login.setVisible(true);
        // TestFinanceTracker.main(args); // Test run
        // TestGUIIntegration.main(args); // Test run
    }
}

